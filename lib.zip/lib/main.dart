import 'package:flutter/material.dart';
import 'package:flutter_demo_project/main/app.dart';

void main() {
  runApp(const App());
}
