abstract interface class BaseState {}
