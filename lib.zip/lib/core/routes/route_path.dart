abstract final class RoutePath {
  RoutePath._();

  static const String intialRoute = '/';
  static const String postDetail = '/postDetail';
}
