class FlavorConfig {}
