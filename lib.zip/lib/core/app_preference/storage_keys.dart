/// Key of the storage that value store in local
abstract final class StorageKeys {
  StorageKeys._();

  static const String token = 'token';
}
